﻿namespace Infestation
{
    using System;

    public class HealthCatalyst : Catalyst, ISupplement
    {
        public HealthCatalyst()
            : base(3, 0, 0)
        {
        }
    }
}
