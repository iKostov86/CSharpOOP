﻿namespace Infestation
{
    using System;

    public class AggressionCatalyst : Catalyst, ISupplement
    {
        public AggressionCatalyst()
            : base(0, 0, 3)
        {
        }
    }
}
