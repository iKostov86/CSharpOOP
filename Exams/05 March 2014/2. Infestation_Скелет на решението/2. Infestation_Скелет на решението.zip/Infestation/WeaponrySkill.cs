﻿namespace Infestation
{
    using System;

    public class WeaponrySkill : Supplement, ISupplement
    {
        public WeaponrySkill()
            : base(0, 0, 0)
        {
        }
    }
}
