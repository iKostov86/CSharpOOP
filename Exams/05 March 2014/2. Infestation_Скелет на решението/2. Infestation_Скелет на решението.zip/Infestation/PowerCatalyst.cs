﻿namespace Infestation
{
    using System;

    public class PowerCatalyst : Catalyst, ISupplement
    {
        public PowerCatalyst()
            : base(0, 3, 0)
        {
        }
    }
}
